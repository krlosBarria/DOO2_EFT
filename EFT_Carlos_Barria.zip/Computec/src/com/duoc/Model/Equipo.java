
package com.duoc.Model;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Evaluación Final Transversal S9
 *
 */
public class Equipo {
    private int id;
    private String marca;
    private String modelo;
    private String cpu;
    private int disco_duro;
    private int ram;
    private double precio;
    private String tipo;
    private int potencia_fuente;
    private String factor_forma;
    private String tamanio_pantalla;
    private String touch;
    private int puertos_usb;

    public Equipo() {
    }

    //Constructor autoincremental id
    public Equipo(String marca, String modelo, String cpu, int disco_duro, int ram, double precio, String tipo, int potencia_fuente, String factor_forma, String tamanio_pantalla, String touch, int puertos_usb) {
        this.marca = marca;
        this.modelo = modelo;
        this.cpu = cpu;
        this.disco_duro = disco_duro;
        this.ram = ram;
        this.precio = precio;
        this.tipo = tipo;
        this.potencia_fuente = potencia_fuente;
        this.factor_forma = factor_forma;
        this.tamanio_pantalla = tamanio_pantalla;
        this.touch = touch;
        this.puertos_usb = puertos_usb;
    }

    //Constructor para actualizar
    public Equipo(int id, String marca, String modelo, String cpu, int disco_duro, int ram, double precio, String tipo, int potencia_fuente, String factor_forma, String tamanio_pantalla, String touch, int puertos_usb) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.cpu = cpu;
        this.disco_duro = disco_duro;
        this.ram = ram;
        this.precio = precio;
        this.tipo = tipo;
        this.potencia_fuente = potencia_fuente;
        this.factor_forma = factor_forma;
        this.tamanio_pantalla = tamanio_pantalla;
        this.touch = touch;
        this.puertos_usb = puertos_usb;
    }
    
    //Getters & Setters 

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getDisco_duro() {
        return disco_duro;
    }

    public void setDisco_duro(int disco_duro) {
        this.disco_duro = disco_duro;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPotencia_fuente() {
        return potencia_fuente;
    }

    public void setPotencia_fuente(int potencia_fuente) {
        this.potencia_fuente = potencia_fuente;
    }

    public String getFactor_forma() {
        return factor_forma;
    }

    public void setFactor_forma(String factor_forma) {
        this.factor_forma = factor_forma;
    }

    public String getTamanio_pantalla() {
        return tamanio_pantalla;
    }

    public void setTamanio_pantalla(String tamanio_pantalla) {
        this.tamanio_pantalla = tamanio_pantalla;
    }

    public String getTouch() {
        return touch;
    }

    public void setTouch(String touch) {
        this.touch = touch;
    }

    public int getPuertos_usb() {
        return puertos_usb;
    }

    public void setPuertos_usb(int puertos_usb) {
        this.puertos_usb = puertos_usb;
    }
    
}
