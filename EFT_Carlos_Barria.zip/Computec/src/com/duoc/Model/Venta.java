package com.duoc.Model;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Evaluación Final Transversal S9
 *
 */
public class Venta {

}
