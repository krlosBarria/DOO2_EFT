
package com.duoc.Model;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Evaluación Final Transversal S9
 *
 */
public class Cliente {
    private int id;
    private String rut;
    private String nombre;
    private String direccion;
    private String comuna;
    private String correo;
    private String telefono;

    //Constructor Vacio
    public Cliente() {
    }
    
    //Constructor autoincremental id
    public Cliente(String rut, String nombre, String direccion, String comuna, String correo, String telefono) {
        this.rut = rut;
        this.nombre = nombre;
        this.direccion = direccion;
        this.comuna = comuna;
        this.correo = correo;
        this.telefono = telefono;
    }
    
    //Constructor con id para actualizar
    public Cliente(int id, String rut, String nombre, String direccion, String comuna, String correo, String telefono) {
        this.id = id;
        this.rut = rut;
        this.nombre = nombre;
        this.direccion = direccion;
        this.comuna = comuna;
        this.correo = correo;
        this.telefono = telefono;
    }

    //Getters & Setters
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
