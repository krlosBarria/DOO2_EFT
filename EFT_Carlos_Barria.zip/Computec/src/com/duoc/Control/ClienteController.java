package com.duoc.Control;

import com.duoc.Model.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @hora: 14:50:21
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class ClienteController {

    private Connection conexion;

    public ClienteController() {
        try {
            this.conexion = DatabaseConnection.getInstance().getConnection();
            System.out.println("conexion establecida CliController");
        } catch (SQLException ex) {
            System.out.println("falla en CliController");
        }
    }

    public boolean agregarCliente(Cliente cliente) {
        String query = "INSERT INTO cliente (rut,nombre, direccion, comuna,correo,telefono) "
                + "VALUES(?,?,?,?,?,?)";

        try (PreparedStatement stInsert = conexion.prepareStatement(query)) {
            stInsert.setString(1, cliente.getRut());
            stInsert.setString(2, cliente.getNombre());
            stInsert.setString(3, cliente.getDireccion());
            stInsert.setString(4, cliente.getComuna());
            stInsert.setString(5, cliente.getCorreo());
            stInsert.setString(6, cliente.getTelefono());
            stInsert.executeUpdate();
            System.out.println("Registro Cliente grabado con Exito!!!");
            return true;
        } catch (SQLException ex) {
            System.out.println("FALLA al registrar Cliente " + ex);
            JOptionPane.showMessageDialog(null, "Falla al registrar " + ex.getMessage());
            return false;
        }
    }
}
