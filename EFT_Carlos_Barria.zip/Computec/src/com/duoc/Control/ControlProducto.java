package com.duoc.Control;

import com.duoc.Model.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Evaluación Final Transversal S9
 *
 */
public class ControlProducto {

    private List<Equipo> equipos;
    private DatabaseConnection conexion;
    
    public ControlProducto() throws SQLException{
        equipos = new ArrayList<>();
        conexion = new DatabaseConnection();
    }
    
    //Consulta de Equipos desde la ListaForm
    public List<Equipo> getEquipos(){
        List<Equipo> equipos = new ArrayList<>();
        String sqlListar = "SELECT * FROM equipo";
        try {
            Connection conexRead = conexion.getConnection();
            if (!conexRead.isClosed()) {
                Statement stConsultar = conexRead.createStatement();
                ResultSet rsListar = stConsultar.executeQuery(sqlListar);
                
                while (rsListar.next()) {
                    String marca = rsListar.getString("marca");
                    String modelo = rsListar.getString("modelo");
                    String cpu = rsListar.getString("cpu");
                    int hdd = rsListar.getInt("disco_duro");
                    int ram = rsListar.getInt("ram");
                    double precio = rsListar.getDouble("precio");
                    String tipo = rsListar.getString("tipo");
                    int portenciaFuente = rsListar.getInt("potencia_fuente");
                    String factor_forma = rsListar.getString("factor_forma");
                    String tamanio = rsListar.getString("tamanio_pantalla");
                    String touch = rsListar.getString("touch");
                    int usb = rsListar.getInt("puertos_usb");
                    Equipo equiposInventario = new Equipo(marca, modelo, cpu, hdd, ram, precio, tipo, portenciaFuente, factor_forma, tamanio, touch, usb);
                    equipos.add(equiposInventario);
                }
            }
            
        } catch (SQLException ex) {
            System.out.println("Error al obtener los datos desde Equipos inventario "+ ex.getMessage());
        }
        return equipos;
    }
}
