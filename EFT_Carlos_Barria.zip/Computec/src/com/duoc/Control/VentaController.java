package com.duoc.Control;

import com.duoc.Model.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @hora: 15:02:46
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class VentaController {

    private Connection conexion;

    public VentaController() {
        try {
            this.conexion = DatabaseConnection.getInstance().getConnection();
            System.out.println("conexion exitosa");
        } catch (SQLException ex) {
            System.out.println("Falla al conectar BD" + ex);
            JOptionPane.showMessageDialog(null, "Falla conexion VentaController " + ex);
        }
    }

    public boolean realizarVenta(int clienteId, int equipoId) {
        String query = "INSERT INTO venta (id_clinet, id_equipo, fecha)"
                + "VALUES (',', NOW())";
        try (PreparedStatement stInsertVenta = conexion.prepareStatement(query)) {
            stInsertVenta.setInt(1, clienteId);
            stInsertVenta.setInt(2, equipoId);
            stInsertVenta.executeUpdate();
            System.out.println("Registro Equipo grabado con Exito!!!");
            return true;
        } catch (SQLException ex) {
            System.out.println("Falla al registrar realizarVenta " + ex);
            JOptionPane.showMessageDialog(null, "Falla al registrar realizarVenta " + ex.getMessage());
            return false;
        }
    }
}
