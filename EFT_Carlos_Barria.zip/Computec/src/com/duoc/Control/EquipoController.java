package com.duoc.Control;

import com.duoc.Model.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @hora: 15:04:54
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class EquipoController {

    private Connection conexion;

    public EquipoController() {
        try {
            this.conexion = DatabaseConnection.getInstance().getConnection();
            System.out.println("Conexion Exitosa, EquipoController¡¡¡");
        } catch (SQLException ex) {
            System.out.println("Falla al conectar EquipoController");
            JOptionPane.showMessageDialog(null, "Falla al registrar " + ex.getMessage());
        }
    }

    public boolean agregarEquipo(Equipo equipo) {

        String query = "INSERT INTO equipo (marca,modelo,cpu,disco_duro,ram,precio,tipo,potencia_fuente,factor_forma,tamanio_pantalla,touch,puertos_usb) "
                + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement stInsertEq = conexion.prepareStatement(query)) {
            stInsertEq.setString(1, equipo.getMarca());
            stInsertEq.setString(2, equipo.getModelo());
            stInsertEq.setString(3, equipo.getCpu());
            stInsertEq.setInt(4, equipo.getDisco_duro());
            stInsertEq.setInt(5, equipo.getRam());
            stInsertEq.setDouble(6, equipo.getPrecio());
            stInsertEq.setString(7, equipo.getTipo());
            stInsertEq.setInt(8, equipo.getPotencia_fuente());
            stInsertEq.setString(9, equipo.getFactor_forma());
            stInsertEq.setString(10, equipo.getTamanio_pantalla());
            stInsertEq.setString(11, equipo.getTouch());
            stInsertEq.setInt(12, equipo.getPuertos_usb());
            stInsertEq.executeUpdate();
            System.out.println("Registro Equipo grabado con Exito!!!");
            return true;
        } catch (SQLException ex) {
            System.out.println("Falla al registrar agregarEquipo " + ex);
            JOptionPane.showMessageDialog(null, "Falla al registrar agregarEquipo " + ex.getMessage());
            return false;
        }
    }
}
