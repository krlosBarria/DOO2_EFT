package com.duoc.Control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 06-10-2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Evaluación Final Transversal S9
 *
 */
public class DatabaseConnection {

    private static DatabaseConnection instance;
    private Connection conexion;
    private String DBNAME = "computecdb";
    private String URL = "jdbc:mysql://localhost:3306/" + DBNAME + "?useSSL=false&serverTimezone=UTC";
    private String USERNAME = "root";
    private String PASSWORD = "eddie";

    DatabaseConnection() throws SQLException {
        try {
            this.conexion = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Conexion a BD " + DBNAME + " Establecida correctamente!!!");
        } catch (SQLException ex) {
            System.out.println("Falla al conectar en DatabaseConnection " + ex.getMessage());
            throw new SQLException(ex);
        }
    }

    public Connection getConnection() {
        return conexion;
    }

    public static DatabaseConnection getInstance() throws SQLException {
        if (instance == null) {
            instance = new DatabaseConnection();
            System.out.println("INSTANCE - conexion exitosa");
        } else if (instance.getConnection().isClosed()) {
            instance = new DatabaseConnection();
            System.out.println("INSTANCE - conexion Fallida");
        }
        return instance;
    }

}
